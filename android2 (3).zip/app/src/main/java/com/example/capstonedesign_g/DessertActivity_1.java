package com.example.capstonedesign_g;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DessertActivity_1 extends AppCompatActivity {

    protected String mRecordingFile;
    SoundPool sound;
    int sound_sandwich;
    int sound_strawberrydounut;
    int sound_chocodounut;
    int sound_waffle;
    int Sound_strawberrycake;

    private static MediaPlayer mp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dessert_1);

        sound = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        sound_sandwich = sound.load(this, R.raw.choice_sandwich, 1);
        sound_strawberrydounut = sound.load(this, R.raw.choice_strawberrytdounut, 1);
        sound_chocodounut = sound.load(this, R.raw.choice_chocodounut, 1);
        sound_waffle = sound.load(this, R.raw.choice_waffle, 1);
        Sound_strawberrycake = sound.load(this, R.raw.choice_strawberrycake, 1);

        mp=MediaPlayer.create(this,R.raw.menu_dessert);
        mp.start();

        Button btn20 = (Button) findViewById(R.id.sandwich);
        btn20.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_sandwich, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn21 = (Button) findViewById(R.id.strawberrydounut);
        btn21.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_strawberrydounut, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn22 = (Button) findViewById(R.id.chocodounut);
        btn22.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_chocodounut, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn23 = (Button) findViewById(R.id.waffle);
        btn23.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_waffle, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn24 = (Button) findViewById(R.id.strawberrycake);
        btn24.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(Sound_strawberrycake, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });


    }

}
