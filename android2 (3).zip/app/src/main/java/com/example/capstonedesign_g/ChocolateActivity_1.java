package com.example.capstonedesign_g;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class ChocolateActivity_1 extends AppCompatActivity {

    protected String mRecordingFile;
    SoundPool sound;
    int sound_icechoco;
    int sound_vanilachoco;
    int sound_mintchoco;
    int sound_strawberrychoco;
    int sound_greenteachoco;

    private static MediaPlayer mp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chocolate_1);

        sound = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        sound_icechoco = sound.load(this, R.raw.choice_icechoco, 1);
        sound_vanilachoco = sound.load(this, R.raw.choice_vanillachoco, 1);
        sound_mintchoco = sound.load(this, R.raw.choice_mintchoco, 1);
        sound_strawberrychoco = sound.load(this, R.raw.choice_strawberrychoco, 1);
        sound_greenteachoco = sound.load(this, R.raw.choice_greenteachoco, 1);

        mp=MediaPlayer.create(this,R.raw.menu_chocolate);
        mp.start();


        Button btn10= (Button) findViewById(R.id.icechoco);
        btn10.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_icechoco, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn11 = (Button) findViewById(R.id.vanilachoco);
        btn11.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_vanilachoco, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn12 = (Button) findViewById(R.id.mintchoco);
        btn12.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_mintchoco, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn13 = (Button) findViewById(R.id.strawberrychoco);
        btn13.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_strawberrychoco, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn14 = (Button) findViewById(R.id.greenteachoco);
        btn14.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_greenteachoco, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });


    }
}
