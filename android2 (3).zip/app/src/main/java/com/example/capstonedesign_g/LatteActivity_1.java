package com.example.capstonedesign_g;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class LatteActivity_1 extends AppCompatActivity {

    protected String mRecordingFile;
    SoundPool sound;
    int sound_cafelatte;
    int sound_vanilalatte;
    int sound_greentealatte;
    int sound_caramellatte;
    int sound_sweetlatte;

    private static MediaPlayer mp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_latte_1);

        sound = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        sound_cafelatte = sound.load(this, R.raw.choice_cafelatte, 1);
        sound_vanilalatte = sound.load(this, R.raw.choice_vanilalatte, 1);
        sound_greentealatte = sound.load(this, R.raw.choice_greentealatte, 1);
        sound_caramellatte = sound.load(this, R.raw.choice_caramellatte, 1);
        sound_sweetlatte = sound.load(this, R.raw.choice_sweetpotato, 1);

        mp=MediaPlayer.create(this,R.raw.menu_latte);
        mp.start();

        Button btn30 = (Button) findViewById(R.id.cafelatte);
        btn30.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_cafelatte, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn31 = (Button) findViewById(R.id.vanilalatte);
        btn31.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_vanilalatte, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn32 = (Button) findViewById(R.id.greentealatte);
        btn32.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_greentealatte, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn33 = (Button) findViewById(R.id.caramellatte);
        btn33.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_caramellatte, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn34 = (Button) findViewById(R.id.sweetlatte);
        btn34.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_sweetlatte, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });


    }
}
