package com.example.capstonedesign_g;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class TeaActivity_1 extends AppCompatActivity {

    protected String mRecordingFile;
    SoundPool sound;
    int sound_urlgray;
    int sound_jasmintea;
    int sound_rosemarytea;
    int sound_kukhwatea;
    int sound_greentea;

    private static MediaPlayer mp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tea_1);

        sound = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        sound_urlgray = sound.load(this, R.raw.choice_urlgray, 1);
        sound_jasmintea = sound.load(this, R.raw.choice_zasmintea, 1);
        sound_rosemarytea = sound.load(this, R.raw.choice_rosemarytea, 1);
        sound_kukhwatea = sound.load(this, R.raw.choice_kukhwatea, 1);
        sound_greentea = sound.load(this, R.raw.choice_greentea, 1);

        mp=MediaPlayer.create(this,R.raw.menu_tea);
        mp.start();

        Button btn35 = (Button) findViewById(R.id.urlgray);
        btn35.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_urlgray, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn36 = (Button) findViewById(R.id.jasmintea);
        btn36.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_jasmintea, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn37 = (Button) findViewById(R.id.rosemarytea);
        btn37.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_rosemarytea, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn38 = (Button) findViewById(R.id.kukhwatea);
        btn38.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_kukhwatea, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn39 = (Button) findViewById(R.id.greentea);
        btn39.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_greentea, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });


    }

}
