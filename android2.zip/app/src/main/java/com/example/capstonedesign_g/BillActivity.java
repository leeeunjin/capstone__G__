package com.example.capstonedesign_g;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

public class BillActivity extends AppCompatActivity implements View.OnClickListener {


    public static final int COFFEE_PRICE = 1500;
    public static final int CREAM_PRICE = 500;

    private int mQuantity = 0;

    private CheckBox mCheckCream;
    private TextView mTvQuantity;
    private TextView mTvSummary;
    private int mQunatity;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill);

        mCheckCream = (CheckBox) findViewById(R.id.cream_chk);
        mTvQuantity = (TextView) findViewById(R.id.quantity_text);
        mTvSummary = (TextView) findViewById(R.id.summary_text);


        // 버튼들 이벤트 처리

        findViewById(R.id.minus_btn).setOnClickListener(this);
        findViewById(R.id.plus_btn).setOnClickListener(this);
        findViewById(R.id.order_btn).setOnClickListener(this);
    }


    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.minus_btn:
                mQuantity--;
                if (mQuantity <0) {
                    mQuantity = 0;
                }
                mTvQuantity.setText("" + mQuantity);
                break;

            case R.id.plus_btn:
                mQuantity++;
                mTvQuantity.setText("" + mQuantity);
                break;
            case R.id.order_btn:
                printSummary();
                break;

        }


    }

    private void printSummary() {
        int totalPrice = COFFEE_PRICE * mQuantity;

        if (mCheckCream.isChecked()) {
            totalPrice += CREAM_PRICE;
        }

        StringBuilder sb = new StringBuilder("[ 주문 확인하기 ]\n");
        sb.append("\n수량 : ").append(mQuantity);
        sb.append("\n휘핑크림 추가 여부 : ").append(mCheckCream.isChecked());
        sb.append("\n합계 : ").append(totalPrice);

        mTvSummary.setText(sb);

    }
}
