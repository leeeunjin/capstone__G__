package com.example.capstonedesign_g;

public class NovoicescreenActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_novoicescreen);
        Intent intent = getIntent();
    }



}
