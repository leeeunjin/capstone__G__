package com.example.capstonedesign_g;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class VoicescreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voicescreen);



        Button buttonc = (Button)findViewById(R.id.coffeehot);
        buttonc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),CoffeehotActivity.class);
                startActivity(intent);

            }


        });

        Button buttond = (Button)findViewById(R.id.lattebutton);
        buttond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),LatteActivity.class);
                startActivity(intent);

            }


        });

        Button buttone = (Button)findViewById(R.id.bubbleteabutton);
        buttone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),BubbleteaActivity.class);
                startActivity(intent);

            }


        });

        Button buttoni = (Button)findViewById(R.id.chocobutton);
        buttoni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),ChocolateActivity.class);
                startActivity(intent);

            }


        });


        Button buttonj = (Button)findViewById(R.id.coffeeice);
        buttonj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),CoffeeiceActivity.class);
                startActivity(intent);

            }


        });


        Button buttonk = (Button)findViewById(R.id.teabutton);
        buttonk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),TeaActivity.class);
                startActivity(intent);

            }


        });


        Button buttonl = (Button)findViewById(R.id.juicebutton);
        buttonl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),JuiceActivity.class);
                startActivity(intent);

            }


        });


        Button buttonm = (Button)findViewById(R.id.dessertbutton);
        buttonm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), DessertActivity.class);
                startActivity(intent);

            }


        });
    }
}
