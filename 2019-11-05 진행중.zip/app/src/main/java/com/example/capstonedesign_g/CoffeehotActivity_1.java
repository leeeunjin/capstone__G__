package com.example.capstonedesign_g;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CoffeehotActivity_1 extends AppCompatActivity {

    protected String mRecordingFile;
    SoundPool sound;
    int sound_americano;
    int sound_esspresso;
    int sound_cappuccino;
    int sound_cafemoca;
    int sound_macciatto;

    private static MediaPlayer mp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coffeehot_1);

        sound = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        sound_americano = sound.load(this, R.raw.choice_americano, 1);
        sound_esspresso = sound.load(this, R.raw.choice_espresso, 1);
        sound_cappuccino = sound.load(this, R.raw.choice_cappucino, 1);
        sound_cafemoca = sound.load(this, R.raw.choice_cafemoca, 1);
        sound_macciatto = sound.load(this, R.raw.choice_macciatto, 1);

        mp=MediaPlayer.create(this,R.raw.menu_hotcoffee);
        mp.start();

        Button buttons = (Button) findViewById(R.id.espressobutton1);
        buttons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), BillActivity.class);
                startActivity(intent);

                sound.play(sound_esspresso, 1f, 1f, 0, 0, 1f);

                mp.stop();

                }
            }
        );

        Button btn6 = (Button) findViewById(R.id.action_button);
        btn6.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_americano, 1f, 1f, 0, 0, 1f);

                mp.stop();

            }
        });

        Button btn7 = (Button) findViewById(R.id.capuchino1);
        btn7.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_cappuccino, 1f, 1f, 0, 0, 1f);

                mp.stop();

            }
        });

        Button btn8 = (Button) findViewById(R.id.cafemoca);
        btn8.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_cafemoca, 1f, 1f, 0, 0, 1f);

                mp.stop();

            }
        });

        Button btn9 = (Button) findViewById(R.id.macciatto);
        btn9.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_macciatto, 1f, 1f, 0, 0, 1f);

                mp.stop();

            }
        });


    }
}