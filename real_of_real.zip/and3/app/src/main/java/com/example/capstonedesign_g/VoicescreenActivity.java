package com.example.capstonedesign_g;


import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class VoicescreenActivity extends AppCompatActivity {

    protected String mRecordingFile;
    SoundPool sound;
    int sound_coffeehotmenu;
    int sound_coffeelattemenu;
    int sound_bubbleteamenu;
    int sound_chocolatemenu;
    int sound_coffeeicemenu;
    int sound_teamenu;
    int sound_juicemenu;
    int sound_dessertmenu;

    private static MediaPlayer mp;

    public boolean onKeyDown(int keyCode,KeyEvent event) {
//        super.onKeyDown(keyCode, event);
        switch (keyCode){
            case KeyEvent.KEYCODE_1:
                Toast.makeText(getApplicationContext(), "1버튼", Toast.LENGTH_LONG).show();
                Intent intent1 = new Intent(getApplicationContext(), CoffeehotActivity_1.class);
                startActivity(intent1);
                return true;

            case KeyEvent.KEYCODE_2:
                Toast.makeText(getApplicationContext(), "2버튼", Toast.LENGTH_LONG).show();
                Intent intent2 = new Intent(getApplicationContext(),LatteActivity_1.class);
                startActivity(intent2);
                return true;

            case KeyEvent.KEYCODE_3:
                Toast.makeText(getApplicationContext(), "3버튼", Toast.LENGTH_LONG).show();
                Intent intent3 = new Intent(getApplicationContext(),BubbleteaActivity_1.class);
                startActivity(intent3);
                return true;

            case KeyEvent.KEYCODE_4:
                Toast.makeText(getApplicationContext(), "4버튼", Toast.LENGTH_LONG).show();
                Intent intent4 = new Intent(getApplicationContext(),ChocolateActivity_1.class);
                startActivity(intent4);
                return true;

            case KeyEvent.KEYCODE_5:
                Toast.makeText(getApplicationContext(), "5버튼", Toast.LENGTH_LONG).show();
                Intent intent5 = new Intent(getApplicationContext(),CoffeeiceActivity_1.class);
                startActivity(intent5);
                return true;

            case KeyEvent.KEYCODE_6:
                Toast.makeText(getApplicationContext(), "6버튼", Toast.LENGTH_LONG).show();
                Intent intent6 = new Intent(getApplicationContext(),TeaActivity_1.class);
                startActivity(intent6);
                return true;

            case KeyEvent.KEYCODE_7:
                Toast.makeText(getApplicationContext(), "7버튼", Toast.LENGTH_LONG).show();
                Intent intent7 = new Intent(getApplicationContext(),JuiceActivity_1.class);
                startActivity(intent7);
                return true;

            case KeyEvent.KEYCODE_8:
                Toast.makeText(getApplicationContext(), "8버튼", Toast.LENGTH_LONG).show();
                Intent intent8 = new Intent(getApplicationContext(),DessertActivity_1.class);
                startActivity(intent8);
                return true;
            case KeyEvent.KEYCODE_BACK:
                Toast.makeText(getApplicationContext(), "8버튼", Toast.LENGTH_LONG).show();
                Intent intentB = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intentB);
                return false;
        }

        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voicescreen);
        sound = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        sound_coffeehotmenu = sound.load(this, R.raw.menu_hotcoffee, 1);
        sound_coffeelattemenu = sound.load(this, R.raw.menu_latte, 1);
        sound_bubbleteamenu = sound.load(this, R.raw.menu_bubbletea, 1);
        sound_chocolatemenu = sound.load(this, R.raw.menu_chocolate, 1);
        sound_coffeeicemenu = sound.load(this, R.raw.menu_icecoffee, 1);
        sound_teamenu = sound.load(this, R.raw.menu_tea, 1);
        sound_juicemenu = sound.load(this, R.raw.menu_juice, 1);
        sound_dessertmenu = sound.load(this, R.raw.menu_dessert, 1);

        mp=MediaPlayer.create(this,R.raw.category);
        mp.start();



        Button buttonc = (Button)findViewById(R.id.coffeehot1);
        buttonc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),CoffeehotActivity_1.class);
                startActivity(intent);

                //sound.play(sound_coffeehotmenu, 1f, 1f, 0, 0, 1f);

                mp.stop();

            }


        });

        Button buttond = (Button)findViewById(R.id.lattebutton1);
        buttond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),LatteActivity_1.class);
                startActivity(intent);

              //  sound.play(sound_coffeelattemenu, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }


        });

        Button buttone = (Button)findViewById(R.id.bubbleteabutton1);
        buttone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),BubbleteaActivity_1.class);
                startActivity(intent);

               // sound.play(sound_bubbleteamenu, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }


        });

        Button buttoni = (Button)findViewById(R.id.chocobutton1);
        buttoni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),ChocolateActivity_1.class);
                startActivity(intent);

               // sound.play(sound_chocolatemenu, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }


        });


        Button buttonj = (Button)findViewById(R.id.coffeeice1);
        buttonj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),CoffeeiceActivity_1.class);
                startActivity(intent);

               // sound.play(sound_coffeeicemenu, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }


        });


        Button buttonk = (Button)findViewById(R.id.teabutton1);
        buttonk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),TeaActivity_1.class);
                startActivity(intent);

              //  sound.play(sound_teamenu, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }


        });


        Button buttonl = (Button)findViewById(R.id.juicebutton1);
        buttonl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),JuiceActivity_1.class);
                startActivity(intent);

              //  sound.play(sound_juicemenu, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }


        });


        Button buttonm = (Button)findViewById(R.id.dessertbutton1);
        buttonm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), DessertActivity_1.class);
                startActivity(intent);

               // sound.play(sound_dessertmenu, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }


        });


    }
}
