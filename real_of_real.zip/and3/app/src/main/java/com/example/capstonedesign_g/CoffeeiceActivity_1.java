package com.example.capstonedesign_g;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CoffeeiceActivity_1 extends AppCompatActivity {

    protected String mRecordingFile;
    SoundPool sound;
    int sound_esspresso3;
    int sound_amercano3;
    int sound_capucino3;
    int sound_cafemoca3;
    int sound_macciatto3;

    private static MediaPlayer mp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coffeeice_1);

        sound = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        sound_esspresso3 = sound.load(this, R.raw.choice_espresso, 1);
        sound_amercano3 = sound.load(this, R.raw.choice_americano, 1);
        sound_capucino3 = sound.load(this, R.raw.choice_cappucino, 1);
        sound_cafemoca3 = sound.load(this, R.raw.choice_cafemoca, 1);
        sound_macciatto3 = sound.load(this, R.raw.choice_macciatto, 1);

        mp=MediaPlayer.create(this,R.raw.menu_icecoffee);
        mp.start();

        Button btn15 = (Button) findViewById(R.id.espressobutton3);
        btn15.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_esspresso3, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn16 = (Button) findViewById(R.id.americanobutton3);
        btn16.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_amercano3, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn17 = (Button) findViewById(R.id.capuchino3);
        btn17.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_capucino3, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn18 = (Button) findViewById(R.id.cafemoca3);
        btn18.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_cafemoca3, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn19 = (Button) findViewById(R.id.macciatto3);
        btn19.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_macciatto3, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });


    }
}
