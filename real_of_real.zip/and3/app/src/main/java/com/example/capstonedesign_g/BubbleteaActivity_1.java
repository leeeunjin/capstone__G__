package com.example.capstonedesign_g;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class BubbleteaActivity_1 extends AppCompatActivity {

    protected String mRecordingFile;
    SoundPool sound;
    int sound_blackbubbletea;
    int sound_tarobubbletea;
    int sound_ujabubbletea;
    int sound_chocobubbletea;
    int sound_strawberrybubbletea;

    private static MediaPlayer mp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bubbletea_1);

        sound = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        sound_blackbubbletea = sound.load(this, R.raw.choice_blackbubbletea, 1);
        sound_tarobubbletea = sound.load(this, R.raw.choice_tarobubbletea, 1);
        sound_ujabubbletea = sound.load(this, R.raw.choice_ujabubbletea, 1);
        sound_chocobubbletea = sound.load(this, R.raw.choice_chocobubbletea, 1);
        sound_strawberrybubbletea = sound.load(this, R.raw.choice_strawberrybubbletea, 1);

        mp=MediaPlayer.create(this,R.raw.menu_bubbletea);
        mp.start();

        Button btn1 = (Button) findViewById(R.id.blackbubbletea);
        btn1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_blackbubbletea, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn2 = (Button) findViewById(R.id.tarobubbletea);
        btn2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_tarobubbletea, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn3 = (Button) findViewById(R.id.ujabubbletea);
        btn3.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_ujabubbletea, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn4 = (Button) findViewById(R.id.chocobubbletea);
        btn4.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_chocobubbletea, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn5 = (Button) findViewById(R.id.strawberrybubbletea);
        btn5.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_strawberrybubbletea, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

    }
}