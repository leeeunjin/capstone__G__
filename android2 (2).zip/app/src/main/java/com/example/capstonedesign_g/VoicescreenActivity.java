package com.example.capstonedesign_g;


import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class VoicescreenActivity extends AppCompatActivity {

    protected String mRecordingFile;
    SoundPool sound;
    int sound_coffeehotmenu;
    int sound_coffeelattemenu;
    int sound_bubbleteamenu;
    int sound_chocolatemenu;
    int sound_coffeeicemenu;
    int sound_teamenu;
    int sound_juicemenu;
    int sound_dessertmenu;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voicescreen);
        sound = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        sound_coffeehotmenu = sound.load(this, R.raw.menu_hotcoffee, 1);
        sound_coffeelattemenu = sound.load(this, R.raw.menu_latte, 1);
        sound_bubbleteamenu = sound.load(this, R.raw.menu_bubbletea, 1);
        sound_chocolatemenu = sound.load(this, R.raw.menu_chocolate, 1);
        sound_coffeeicemenu = sound.load(this, R.raw.menu_icecoffee, 1);
        sound_teamenu = sound.load(this, R.raw.menu_tea, 1);
        sound_juicemenu = sound.load(this, R.raw.menu_juice, 1);
        sound_dessertmenu = sound.load(this, R.raw.menu_dessert, 1);

        Button buttonc = (Button)findViewById(R.id.coffeehot1);
        buttonc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),CoffeehotActivity_1.class);
                startActivity(intent);

                sound.play(sound_coffeehotmenu, 1f, 1f, 0, 0, 1f);
            }


        });

        Button buttond = (Button)findViewById(R.id.lattebutton1);
        buttond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),LatteActivity_1.class);
                startActivity(intent);

                sound.play(sound_coffeelattemenu, 1f, 1f, 0, 0, 1f);
            }


        });

        Button buttone = (Button)findViewById(R.id.bubbleteabutton1);
        buttone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),BubbleteaActivity_1.class);
                startActivity(intent);

                sound.play(sound_bubbleteamenu, 1f, 1f, 0, 0, 1f);
            }


        });

        Button buttoni = (Button)findViewById(R.id.chocobutton1);
        buttoni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),ChocolateActivity_1.class);
                startActivity(intent);

                sound.play(sound_chocolatemenu, 1f, 1f, 0, 0, 1f);
            }


        });


        Button buttonj = (Button)findViewById(R.id.coffeeice1);
        buttonj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),CoffeeiceActivity_1.class);
                startActivity(intent);

                sound.play(sound_coffeeicemenu, 1f, 1f, 0, 0, 1f);
            }


        });


        Button buttonk = (Button)findViewById(R.id.teabutton1);
        buttonk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),TeaActivity_1.class);
                startActivity(intent);

                sound.play(sound_teamenu, 1f, 1f, 0, 0, 1f);
            }


        });


        Button buttonl = (Button)findViewById(R.id.juicebutton1);
        buttonl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),JuiceActivity_1.class);
                startActivity(intent);

                sound.play(sound_juicemenu, 1f, 1f, 0, 0, 1f);
            }


        });


        Button buttonm = (Button)findViewById(R.id.dessertbutton1);
        buttonm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), DessertActivity_1.class);
                startActivity(intent);

                sound.play(sound_dessertmenu, 1f, 1f, 0, 0, 1f);
            }


        });
    }
}
