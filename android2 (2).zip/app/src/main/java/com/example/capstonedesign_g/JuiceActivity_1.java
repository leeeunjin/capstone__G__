package com.example.capstonedesign_g;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class JuiceActivity_1 extends AppCompatActivity {

    protected String mRecordingFile;
    SoundPool sound;
    int sound_strawberryjuice;
    int sound_carrotjuice;
    int sound_kiwijuice;
    int sound_grapejuice;
    int sound_watermelonjuice;

    private static MediaPlayer mp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juice_1);

        sound = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        sound_strawberryjuice = sound.load(this, R.raw.choice_strawberryjuice, 1);
        sound_carrotjuice= sound.load(this, R.raw.choice_carrotjuice, 1);
        sound_kiwijuice= sound.load(this, R.raw.choice_kiwijuice, 1);
        sound_grapejuice= sound.load(this, R.raw.choice_garpejuice, 1);
        sound_watermelonjuice= sound.load(this, R.raw.choice_watermelonjuice, 1);

        mp=MediaPlayer.create(this,R.raw.menu_juice);
        mp.start();

        Button btn25 = (Button) findViewById(R.id.strawberryjuice);
        btn25.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_strawberryjuice, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn40 = (Button) findViewById(R.id.carrotjuice);
        btn40.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_carrotjuice, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn26 = (Button) findViewById(R.id.kiwijuice);
        btn26.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_kiwijuice, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn27 = (Button) findViewById(R.id.grapejuice);
        btn27.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_grapejuice, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });

        Button btn28 = (Button) findViewById(R.id.watermelonjuice);
        btn28.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_watermelonjuice, 1f, 1f, 0, 0, 1f);

                mp.stop();
            }
        });


    }

}
