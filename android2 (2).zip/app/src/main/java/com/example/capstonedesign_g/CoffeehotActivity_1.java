package com.example.capstonedesign_g;

import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CoffeehotActivity_1 extends AppCompatActivity {

    protected String mRecordingFile;
    SoundPool sound;
    int sound_americano;
    int sound_esspresso;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coffeehot_1);

        sound = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        sound_americano = sound.load(this, R.raw.choice_americano, 1);
        sound_esspresso = sound.load(this, R.raw.choice_espresso, 1);

        Button buttons = (Button) findViewById(R.id.espressobutton1);
        buttons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), BillActivity.class);
                startActivity(intent);

                sound.play(sound_esspresso, 1f, 1f, 0, 0, 1f);
                }
            }
        );

        Button btn = (Button) findViewById(R.id.americanobutton1);
        btn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                sound.play(sound_americano, 1f, 1f, 0, 0, 1f);
            }
        });


    }
}