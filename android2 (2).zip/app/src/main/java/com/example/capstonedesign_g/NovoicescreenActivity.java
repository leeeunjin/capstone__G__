package com.example.capstonedesign_g;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class NovoicescreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_novoicescreen);



        Button buttonf = (Button)findViewById(R.id.coffeehot);
        buttonf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),CoffeehotActivity.class);
                startActivity(intent);

            }


        });



        Button buttong = (Button)findViewById(R.id.lattebutton);
        buttong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),LatteActivity.class);
                startActivity(intent);

            }


        });

        Button buttonh = (Button)findViewById(R.id.bubbleteabutton);
        buttonh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),BubbleteaActivity.class);
                startActivity(intent);

            }


        });


        Button buttonn = (Button)findViewById(R.id.chocobutton);
        buttonn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),ChocolateActivity.class);
                startActivity(intent);

            }


        });


        Button buttono = (Button)findViewById(R.id.coffeeice);
        buttono.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),CoffeeiceActivity.class);
                startActivity(intent);

            }


        });


        Button buttonp = (Button)findViewById(R.id.teabutton);
        buttonp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),TeaActivity.class);
                startActivity(intent);

            }


        });


        Button buttonq = (Button)findViewById(R.id.juicebutton);
        buttonq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),JuiceActivity.class);
                startActivity(intent);

            }


        });


        Button buttonr = (Button)findViewById(R.id.dessertbutton);
        buttonr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), DessertActivity.class);
                startActivity(intent);

            }


        });

    }



}
