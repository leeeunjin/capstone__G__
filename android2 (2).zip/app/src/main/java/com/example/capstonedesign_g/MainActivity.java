package com.example.capstonedesign_g;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    protected  String mRecordingFile;
    SoundPool sound;
    int sound_category;

    private static MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sound = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
        sound_category = sound.load(this, R.raw.category, 1);

        mp=MediaPlayer.create(this,R.raw.first_screen);
        mp.start();


        Button button = (Button)findViewById(R.id.voicebutton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),VoicescreenActivity.class);
                startActivity(intent);

                mp.stop();
            }


        });



        Button buttona = (Button)findViewById(R.id.nextbutton);
        buttona.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),NovoicescreenActivity.class);
                startActivity(intent);

            }


        });


        Button buttonb = (Button)findViewById(R.id.qrbutton);
        buttonb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),QrcodeActivity.class);
                startActivity(intent);

            }


        });


    }

}